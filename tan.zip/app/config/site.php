<?php
return array(
	'url_image' => Asset('') . 'store/images/',
	'url_thumb' => Asset('') . 'store/upload/images/',
	'url_css' => Asset('') . 'store/css/',
	'url_js' => Asset('') . 'store/js/',
	'url_font' => Asset('') . 'store/fonts/',
	'menu_type' => array('introduction', 'event', 'salon', 'hiring', 'product', 'contact', 'news'),
);
?>
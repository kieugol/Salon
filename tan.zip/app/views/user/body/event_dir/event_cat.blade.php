﻿<?php
$_images = Config::get('site.url_image');
$_thumb = Config::get('site.url_thumb');
$_css = Config::get('site.url_css');
$_js = Config::get('site.url_js');
$is_padding = 0;
$pdTop = '';
?>
@extends('user.main')
@section('css')
  <title>Sự kiện</title>
  <link rel="stylesheet" href="{{$_css . 'custom.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'bootstrap.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'theme-color.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'responsive.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'owl.carousel.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'jquery.bxslider.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'prettyPhoto.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'font-awesome.min.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'icomoon.css'}}" type="text/css">
@stop

@section('content')
  <div class="cp_inner-banner">
    <div class="cp-inner-image">
      <img src="{{$_images}}/inner-event-1-img.jpg" alt="">
    </div>
    <div class="cp_breadcrumb-holder">
      <div class="container">
        <h1>Sự kiện tại TP HCM</h1>
      </div>
    </div>
  </div>

 <div class="cp_main">
  <section class="cp_events-section pd-tb80">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
      @foreach($list_event_cat as $id => $eventcat)
        <div class="cp-heding-style1{{$pdTop}}"><h2>{{$eventcat[1]}}</h2></div>
          <ul class="cp-events-listed">
          @foreach($list_event as $event)
          @if($event->id_event_categories == $id)
           <?php $alias_event = Asset('/su-kien') . '/' . $event->alias_event_categories . '/' . $event->alias_event . '/' . $event->id_event . '.html'?>
            <li>
              <div class="cp-events-box">
                <figure class="cp-thumb">
                  <img src="{{$_thumb . $event->thumb_event}}" style="max-width:320px" alt="">
                </figure>
                <div class="text">
                  <h2>{{$event->name_event}}</h2>
                  <p>{{$event->short_desc_event}}</p>
                  <span class="small-box"><span>Địa điểm</span> {{$event->address_salon}}</span>
                  <a href="{{$alias_event}}" class="cp-btn-style2">Chi tiết</a>
                  <a href="{{Asset('su-kien/dat-hen') . '/' . $event->alias_event_categories . '/' .  $event->alias_event . '/' . $event->id_event}}.html" class="cp-btn-style2">Đặt hẹn</a>
                </div>
              </div>
            </li>
          @endif
          @endforeach
          </ul>
      <?php $is_padding++;
if ($is_padding > 0) {
	$pdTop = ' mt40';
}
?>
      @endforeach
          <!-- Start topic-->
          <div class="cp_pagination-holder">
<!--             <ul class="pagination">
              <li>
                <a href="#" aria-label="Previous">
                  Previous
                </a>
              </li>
              <li><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li>
                <a href="#" aria-label="Next">
                  Next
                </a>
              </li>
            </ul> -->

          </div>
        </div>


        <div class="col-md-3">
          <aside class="cp_sidebar">
            <div class="cp-sidebar-box">
              <h3>Tin mới cập nhật</h3>
              <ul class="cp-sidebar-post">
                <li>
                  <div class="holder">
                    <div class="thumb">
                      <img src="{{$_images}}/post-thumb-01.jpg" alt="">
                    </div>
                    <div class="text">
                      <strong><a href="#">Kiểu tóc 2016</a></strong>
                      <ul class="cp_meta-listed">
                        <li>Đăng bởi <a href="#">Admin</a></li>
                      </ul>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="holder">
                    <div class="thumb">
                      <img src="{{$_images}}/post-thumb-02.jpg" alt="">
                    </div>
                    <div class="text">
                      <strong><a href="#">Kiểu tóc dạo phố</a></strong>
                      <ul class="cp_meta-listed">
                        <li>Đăng bởi <a href="#">Admin</a></li>
                      </ul>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="holder">
                    <div class="thumb">
                      <img src="{{$_images}}/post-thumb-03.jpg" alt="">
                    </div>
                    <div class="text">
                      <strong><a href="#">Kiểu tóc dự tiệc</a></strong>
                      <ul class="cp_meta-listed">
                        <li>Đăng bởi <a href="#">Admin</a></li>
                      </ul>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </aside>
        </div>

      </div>
    </div>
  </section>
</div>

@stop

@section('script')
  <script type="text/javascript" src="{{$_js . 'html5shiv.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'jQuery.1.11.3.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'bootstrap.min.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'migrate.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'owl.carousel.min.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'jquery.bxslider.min.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'jquery.isotope.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'jquery.prettyPhoto.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'custom-script.js'}}"></script>
@stop
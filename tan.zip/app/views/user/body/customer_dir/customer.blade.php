@extends('user.main')
@section('seo')
   <meta name="keywords" content="{{$menus['meta_key_menus']}}">
   <meta name="title" content="{{$menus['meta_title_menus']}}">
   <meta name="description" content="{{$menus['meta_desc_menus']}}">
   <title>{{$menus['title_menus']}}</title>
@stop
@section('content')
<script>
  var _alias_menus = '{{$menus["alias_menus"]}}';
  $(".nav li").each(function() {
    if($(this).attr('id') == _alias_menus){
      $(this).addClass('active');
    }
  });
</script>
<div class="container hc-body-content">
      @include('user.menu_left')
      <!--Main Content-->
      <div class=" hc-adv-top-content">
           <div class="breadcrumb">
            <ul>
              <li><a href="{{Asset('/')}}">Trang chủ</a></li>
               <li><a href="{{Asset('/').$menus['alias_menus'].'.html'}}"><img src="{{Asset('store/images/breadcrumb.png')}}">&nbsp;{{$menus['title_menus']}}</a></li>
              <div class="clr"></div>
            </ul>
          </div>
          <section class="hc-news clr-lr">
              <div class="title-categories title-categories-add"><h2 class="clr-services">{{$menus['title_menus']}}</h2></div>
              @if(count($list_customer)>0)
                <ul class="customer">
                @foreach($list_customer as $result)
                    <li>
                        <a href="{{$result->url}}" target="_blank">
                           <img src="<?php echo Asset('/')."store/upload/images/".$result->name_file ?>" alt="{{$result->name_file}}">
                        </a>
                    </li>
                @endforeach
                </ul>
              @endif
          </section>
      </div>
      <!--End Main Content./-->
      @include('user.adv_right')
</div>
@stop
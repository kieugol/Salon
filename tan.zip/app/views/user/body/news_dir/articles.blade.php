@extends('user.main')
@section('seo')

   <meta name="keywords" content="{{$articles_details['meta_key_articles']}}">
   <meta name="title" content="{{$articles_details['meta_title_articles']}}">
   <meta name="description" content="{{$articles_details['meta_desc_articles']}}">
   <title>{{$articles_details['title_articles']}}</title>
@stop
@section('content')
<script>
  var _alias_menus = '{{$articles_details["alias_menus"]}}';
  $(".nav li").each(function() {
    if($(this).attr('id') == _alias_menus){
      $(this).addClass('active');
    }
  });
</script>
<div class="container hc-body-content">
      @include('user.menu_left')
      <!--Main Content-->
      <div class=" hc-adv-top-content">
        <?php
            $alias_breadrumb ="";
              if($articles_details['ordering_articles_categories'] ==$id_categories_min)
                $alias_breadrumb = Asset('/tin-tuc').'/'.$articles_details['alias_articles_categories'].'.html';
              else
                 $alias_breadrumb = Asset('/').$articles_details['alias_articles_categories'].'.html';
        ?>
          <div class="breadcrumb">
            <ul>
              <li><a href="{{Asset('/')}}">Trang chủ</a></li>
               <li><a href="{{$alias_breadrumb}}"><img src="{{Asset('store/images/breadcrumb.png')}}">&nbsp;{{$articles_details['name_articles_categories']}}</a></li>
              <li><a class="color-bread" ><img src="{{Asset('store/images/breadcrumb.png')}}">&nbsp;{{$articles_details['title_articles']}}</a></li>
              <div class="clr"></div>
            </ul>
          </div>
          <section class="hc-articles">
              <h3 class="title-articles">{{$articles_details['title_articles']}}</h3>
              <div class="info-articles">
                <p class="topic-articles"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;{{date_format($articles_details['created_at'],'d/m/Y') }}</p>
                <p class="topic-articles"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;{{$articles_details['related_articles']}}</p>
              </div>
              <article class="content-articles">
                {{$articles_details['fulltext_articles']}}
                <div class="mt10"></div>
                <div class="text-left">
                  <div class='addthis_toolbox addthis_default_style'>
                  <a class='addthis_button_facebook_like' fb:like:layout='button_count'></a>
                  <a class='addthis_button_tweet'></a>
                  <a class='addthis_button_google_plusone' g:plusone:size='medium'></a>
                  </div>
                  <script src='http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-4ec4dd3d1e59e9dc' type='text/javascript'></script>
                </div>
              </article>
          </section>
        @if(count($listLinkArticles)>0)
           <section class="news-more">
              <div class="title-categories title-categories-add"><h2 class="title-news">Tin khác</h2></div>
              <ul class="hc-news-other">
              @foreach($listLinkArticles as $result)
                <li><a href="{{Asset('/tin-tuc').'/'.$result->alias_articles_categories.'/'.$result->alias_articles.'.html'}}">{{$result->title_articles}}</a><span>({{date_format( $result->created_at,'d/m/Y' )}})</span></li>
              @endforeach
              </ul>
          </section>
        @endif
      </div>
      <!--End Main Content./-->
      @include('user.adv_right')
</div>
@stop
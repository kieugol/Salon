@extends('user.main')
@section('seo')
   <meta name="keywords" content="{{$menus['meta_key_menus']}}">
   <meta name="title" content="{{$menus['meta_title_menus']}}">
   <meta name="description" content="{{$menus['meta_desc_menus']}}">
   <title>{{$menus['title_menus']}}</title>
@stop
@section('content')
<script>
  var _alias_menus = '{{$menus["alias_menus"]}}';
  $(".nav li").each(function() {
    if($(this).attr('id') == _alias_menus){
      $(this).addClass('active');
    }
  });
</script>
<div class="container hc-body-content">
      @include('user.menu_left')
      <!--Main Content-->
      <div class=" hc-adv-top-content">
           <div class="breadcrumb">
            <ul>
              <li><a href="{{Asset('/')}}">Trang chủ</a></li>
               <li><a href="{{Asset('/').$menus['alias_menus'].'.html'}}"><img src="{{Asset('store/images/breadcrumb.png')}}">&nbsp;{{$menus['title_menus']}}</a></li>
              <div class="clr"></div>
            </ul>
          </div>
          <div class="title-categories title-categories-add"><h2 class="clr-services">{{$menus['title_menus']}}</h2></div>
          <section class="hc-news ">
            <?php
              $qty = count($list_articles);
            ?>
              @foreach($list_articles as $key =>$value)
                <div class="item-articles <?php if ($key<$qty-1) echo "br-bt" ?>" >
                    <div class="thumnail">
                      <a href="{{Asset('/tin-tuc')."/".$list_articles[$key]->alias_articles_categories."/".$list_articles[$key]->alias_articles.".html"}}" title="{{$list_articles[$key]->title_articles}}">
                        <img src="{{Asset('/store/upload/images').'/'.$list_articles[$key]->thumb_articles}}" alt="{{$list_articles[$key]->title_articles}}">
                      </a>
                    </div>
                    <div class="sort-content">
                        <h3><a href="{{Asset('/tin-tuc').'/'.$list_articles[$key]->alias_articles_categories.'/'.$list_articles[$key]->alias_articles.'.html'}}">{{substr($list_articles[$key]->title_articles,0,75)}}</a></h3>
                        <div class="clr"></div>
                        <div class="meta-blog">
                          <span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;{{$list_articles[$key]->related_articles}}&nbsp;&nbsp;&nbsp;&nbsp;
                          <span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;{{date_format( $list_articles[$key]->created_at,'j F Y')}}
                        </div>
                        <p class="intro-text">{{mb_strimwidth($list_articles[$key]->introtext_articles,0,203,"...","utf-8")}}</p>
                    </div>
                    <div class="clr"></div>
                </div>
              @endforeach
            <div class="paginate text-center">
              {{$list_articles->links()}}
            </div>
          </section>
      </div>
      <!--End Main Content./-->
      @include('user.adv_right')
</div>

@stop
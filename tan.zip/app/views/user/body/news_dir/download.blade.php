@extends('user.main')
@section('seo')
   <meta name="keywords" content="{{$menus['meta_key_menus']}}">
   <meta name="title" content="{{$menus['meta_title_menus']}}">
   <meta name="description" content="{{$menus['meta_desc_menus']}}">
   <title>{{$menus['title_menus']}}</title>
@stop
@section('script')
<link rel="stylesheet" type="text/css" href="<?php echo Asset('/')?>store/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo Asset('/')?>store/css/edit.css">
    <link href="<?php echo Asset('/')?>store/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo Asset('/')?>store/css/slider-project/jquery.excoloSlider.css" rel="stylesheet">
     <link href="<?php echo Asset('/')?>store/css/vertical.css" rel="stylesheet">
     <link href="<?php echo Asset('/')?>store/admin/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Jquery -->
    <script type="text/javascript" src="<?php echo Asset('/')?>store/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo Asset('/')?>store/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo Asset('/')?>store/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="<?php echo Asset('/')?>store/js/bootstrap.min.js"></script>
    <!-- Slider -->
    <script type="text/javascript" src="<?php echo Asset('/')?>store/js/slider-project/jquery.excoloSlider.min.js"></script>
     <script type="text/javascript" src="<?php echo Asset('/')?>store/js/scriptbreaker-multiple-accordion.js"></script>
@stop

@section('content')
<script>
  var _alias_menus = '{{$menus["alias_menus"]}}';
  $(".nav li").each(function() {
    if($(this).attr('id') == _alias_menus){
      $(this).addClass('active');
    }
  });
</script>
<div class="container hc-body-content">
      @include('user.menu_left')
      <!--Main Content-->
      <div class=" hc-adv-top-content">
          <div class="breadcrumb">
            <ul>
              <li><a href="{{Asset('/')}}">Trang chủ</a></li>
              <li><a href="{{Asset('/').$menus['title_menus'].'.html'}}"><img src="{{Asset('store/images/breadcrumb.png')}}">&nbsp;{{$menus['title_menus']}}</a></li>
              <div class="clr"></div>
            </ul>
          </div>
          <section class="hc-news clr-lr ">
              <div class="title-categories title-categories-add"><h2 class="clr-services">Download phần mềm , tài liệu sử dụng</h2></div>
            @if(count($list_dlcat)>0) 
              <ul class="download">
                @foreach($list_dlcat as $result )
                  <li>
                    <a > <img src="{{ Asset('/store/images/plus-24px.png')}}" >&nbsp{{$result->name_download_categories}}</a>
                      @if(count($list_dlcat)>0)
                        <ul class="download_child">
                            <li>
                                <table class="table table-bordered table-striped ">
                                    <tbody>
                                      <tr>
                                        <th width="500">Tên phầm mềm</th>
                                        <th>Link download</th>
                                      </tr>
                                      @foreach($list_dl as $result_dl )
                                        @if($result->idDownloadCategories == $result_dl->categories_id )
                                          <tr>
                                              <td>{{$result_dl->title_download}}</td>
                                              <td> <a class="download-document" href="{{$result_dl->url_download}}" target="_blank">download</a></td>
                                          </tr>
                                        @endif
                                      @endforeach
                                    </tbody>
                                  </table>
                              </li>
                          </ul>
                        @endif
                  </li>
                @endforeach
              </ul>
            @endif
          </section>
      </div>
      <script type="text/javascript">
       $(document).ready(function() {
          $('.download ul').hide();
          $('.download li').click(function() {
              $(this).children('.subLink').toggle(400);
          });
            $('.download ul').addClass('subLink');
        });
    </script>
      <!--End Main Content./-->
      @include('user.adv_right')
</div>

@stop
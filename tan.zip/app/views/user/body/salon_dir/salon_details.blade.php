<?php

$_images = Config::get('site.url_image');

$_thumb = Config::get('site.url_thumb');

$_css = Config::get('site.url_css');

$_js = Config::get('site.url_js');

?>

@extends('user.main')

@section('css')

  <title>{{$salon_details['name_salon']}}</title>

  <link rel="stylesheet" href="{{$_css . 'custom.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'bootstrap.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'theme-color.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'responsive.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'owl.carousel.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'jquery.bxslider.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'prettyPhoto.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'font-awesome.min.css'}}" type="text/css">

  <link rel="stylesheet" href="{{$_css . 'icomoon.css'}}" type="text/css">

  <!-- tab -->

  <link rel="stylesheet" href="{{$_css . 'demo-tab.css'}}" type="text/css"/>

  <link rel="stylesheet" href="{{$_css . 'component-tab.css'}}" type="text/css" />

  <link rel="stylesheet" href="{{$_css . 'vernisage-stack-v/engine1/style.css'}}" type="text/css"/>

  <style type="text/css" media="screen">

    iframe{

      width: 100%;

    }
    #section-2 img{
      max-width: 100% !important;
    }

  </style>

@stop

@section('content')

  <div class="cp_inner-banner">

    <div class="cp-inner-image">

      <img src="{{$_thumb . $salon_details['banner_salon']}}" alt="">

    </div>

    <!-- <div class="cp_breadcrumb-holder">

      <div class="container">

        <ul class="breadcrumb">

          <li><a href="{{Asset('/')}}">Trang chủ</a></li>

          <li class="active">{{$salon_details['name_salon']}}</li>

        </ul>

      </div>

    </div> -->

  </div>



  <div class="cp_main">

    <section class="cp_gallery-section pt30">

      <div class="container">

      <div class="logo">

        <div class="logo-salon">

            <img width="140" src="{{$_thumb . $salon_details['thumb_salon']}}" alt="author"></span>

        </div>

        <div class="cp-heding-style1 right-logo">

          <h1>{{$salon_details['name_salon']}}</h1>

        </div>

        <div style="clear:both;"></div>

      </div>

      <!-- logo end -->

        <!-- Start tab -->

        <div id="tabs" class="tabs">

          <nav>

            <ul>

              <li>

                <a href="#section-1">

                  <i class="fa fa-file-image-o" aria-hidden="true"></i>

                  <span> Hình ảnh</span>

                </a>

              </li>

              <li><a href="#section-2"><i class="fa fa-money" aria-hidden="true"></i><span> Bảng giá</span></a></li>

              <li><a href="#section-3"><i class="fa fa-fax" aria-hidden="true"></i><span> Liên hệ</span></a></li>

              <li><a href="#section-4"><i class="fa fa-map-marker" aria-hidden="true"></i><span>Chỉ đường</span></a></li>

              <li><a href="#section-5"><i class="fa fa-newspaper-o" aria-hidden="true"></i><span> Sự kiện</span></a></li>

            </ul>

          </nav>

          <div class="content">

            <section id="section-1">



              <!-- Start slider stack -->

                <div class="ruled1">

                  <!-- Start WOWSlider.com BODY section -->

                  <div id="wowslider-container1">

                    <div class="ws_images">

                      <ul>

                        @foreach($list_gallery as $gallery)

                          <li><img src="{{$_thumb . $gallery->name_file}}"  title=""/></li>

                        @endforeach

                      </ul>

                    </div>

                    <div class="ws_thumbs">

                      <div>

                        <ul>

                         @foreach($list_gallery as $gallery)

                          <a href="#"><img width="130" height="62" src="{{$_thumb . $gallery->name_file}}"/></a>

                          @endforeach

                        </ul>

                      </div>

                    </div>

                    <div class="ws_shadow"></div>

                  </div>

                  <!-- End WOWSlider.com BODY section -->

                </div><!-- end slider stack -->

            </section>

            <section id="section-2">{{$salon_details['price_salon']}}</section>



            <section id="section-3">{{$salon_details['contact_salon']}}</section>



            <section id="section-4">{{$salon_details['maps_salon']}}</section>



            <section id="section-5"></section>

          </div><!-- /content -->

        </div><!-- /tabs -->

        <!-- End tab -->

      </div>

    </section>



  </div>

@stop

@section('script')

  <script type="text/javascript" src="{{$_js . 'jQuery.1.11.3.js'}}"></script>

  <script type="text/javascript" src="{{$_js . 'a.js'}}"></script>

  <script type="text/javascript" src="{{$_js . 'html5shiv.js'}}"></script>

  <script type="text/javascript" src="{{$_js . 'bootstrap.min.js'}}"></script>

  <script type="text/javascript" src="{{$_js . 'migrate.js'}}"></script>

  <script type="text/javascript" src="{{$_js . 'jquery.isotope.js'}}"></script>

  <script src="{{$_js . 'cbpFWTabs-tab.js'}}"></script>

  <script>

    new CBPFWTabs( document.getElementById('tabs'));

  </script>

  <!-- Start Slider -->

  <script type="text/javascript" src="{{$_js . 'salon-gallery/wowslider.js'}}"></script>

  <script type="text/javascript" src="{{$_js . 'vernisage-stack-v/engine1/script.js'}}"></script>

@stop




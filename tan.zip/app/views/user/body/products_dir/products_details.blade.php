<?php
$_images = Config::get('site.url_image');
$_thumb = Config::get('site.url_thumb');
$_css = Config::get('site.url_css');
$_js = Config::get('site.url_js');
?>
@extends('user.main')
@section('css')
  <title>Địa chỉ làm tóc</title>
  <link rel="stylesheet" href="{{$_css . 'custom.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'bootstrap.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'theme-color.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'responsive.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'owl.carousel.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'jquery.bxslider.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'prettyPhoto.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'font-awesome.min.css'}}" type="text/css">
  <link rel="stylesheet" href="{{$_css . 'icomoon.css'}}" type="text/css">
  <!-- tab -->
  <link rel="stylesheet" href="{{$_css . 'demo-tab.css'}}" type="text/css"/>
  <link rel="stylesheet" href="{{$_css . 'component-tab.css'}}" type="text/css" />
  <link rel="stylesheet" href="{{$_css . 'vernisage-stack-v/engine1/style.css'}}" type="text/css"/>
@stop
@section('content')
  <div class="cp_inner-banner">
    <div class="cp-inner-image">
      <img src="{{$_thumb . 'inner-services-img.jpg'}}" alt="">
    </div>
    <div class="cp_breadcrumb-holder">
      <div class="container">
        <h1>Hệ thống salon tóc</h1>
        <ul class="breadcrumb">
          <li><a href="index-2.html">Home</a></li>
          <li class="active">Services</li>
        </ul>
      </div>
    </div>
  </div>

  <div class="cp_main">
    <section class="cp_gallery-section pd-tb80">
      <div class="container">
      <!-- start logo  -->
      <div class="Featured-Author">
          <div class="left">
            <span class="author-img-holder"><img width="160" src="{{$_thumb . 'john-bi/johnbi.jpg'}}" alt="author"></span>
          </div>
      </div>
      <!-- logo end -->
        <!-- Start tab -->
        <div id="tabs" class="tabs">
          <nav>
            <ul>
              <li>
                <a href="#section-1" class="">
                  <span>Hình ảnh</span>
                </a>
              </li>
              <li><a href="#section-2" class=""><span>Bảng giá</span></a></li>
              <li><a href="#section-3" class=""><span>Liên hệ</span></a></li>
              <li><a href="#section-4" class=""><span>Maps</span></a></li>
              <li><a href="#section-5" class=""><span>Sự kiện</span></a></li>
            </ul>
          </nav>
          <div class="content">
            <section id="section-1">

              <!-- Start slider stack -->
                <div class="ruled1">
                  <!-- Start WOWSlider.com BODY section -->
                  <div id="wowslider-container1">
                    <div class="ws_images">
                      <ul>
                        <li><img src="store/images/john-bi/1.JPG"  title=""/></li>
                        <li><img src="store/images/john-bi/2.JPG"  title=""/></li>
                        <li><img src="store/images/john-bi/3.JPG"  title=""/></li>
                        <li><img src="store/images/john-bi/4.JPG"  title=""/></li>
                        <li><img src="store/images/john-bi/5.JPG"  title=""/></li>
                        <li><img src="store/images/john-bi/6.JPG"  title=""/></li>
                        <li><img src="store/images/john-bi/7.JPG"  title=""/></li>
                      </ul>
                    </div>
                    <div class="ws_thumbs">
                      <div>
                        <ul>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/1.JPG"/></a>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/2.JPG"/></a>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/3.JPG"/></a>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/4.JPG"/></a>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/5.JPG"/></a>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/6.JPG"/></a>
                          <a href="#"><img width="130" height="62" src="store/images/john-bi/7.JPG"/></a>
                        </ul>
                      </div>
                    </div>
                    <div class="ws_shadow"></div>
                  </div>
                  <!-- End WOWSlider.com BODY section -->
                </div><!-- end slider stack -->
            </section>
            <section id="section-2">

            </section>
            <section id="section-3">

            </section>
            <section id="section-4">
            </section>
            <section id="section-5">
            </section>
          </div><!-- /content -->
        </div><!-- /tabs -->
        <!-- End tab -->
      </div>
    </section>
  </div>
@stop
@section('script')
  <script type="text/javascript" src="{{$_js . 'jQuery.1.11.3.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'jQuery.1.11.3.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'a.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'html5shiv.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'bootstrap.min.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'migrate.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'jquery.isotope.js'}}"></script>
  <script src="{{$_js . 'cbpFWTabs-tab.js'}}"></script>
  <script>
    new CBPFWTabs( document.getElementById('tabs'));
  </script>
  <!-- Start Slider -->
  <script type="text/javascript" src="{{$_js . 'salon-gallery/wowslider.js'}}"></script>
  <script type="text/javascript" src="{{$_js . 'vernisage-stack-v/engine1/script.js'}}"></script>
@stop
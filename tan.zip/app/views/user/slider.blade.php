        <!-- Start Slider-->
    <div class="cp_banner">
      <div id="cp_banner-slider" class="owl-carousel">
        <div class="item">
          <img src="store/img/banner/banner-img-01.jpg" alt="">
          <div class="container">
            <div class="banner-caption">
              <h1>Sự kiện cắt tóc giảm giá 30%</h1>
           
            </div>
          </div>
        </div>
        <div class="item">
          <img src="store/img/banner/banner-img-02.jpg" alt="">
          <div class="container">

            <div class="banner-caption">
              <h1>Cắt + uốn + duỗi giảm giá 40%</h1>
              
            </div>
          </div>
        </div>
        <div class="item">
          <img src="store/img/banner/banner-img-03.jpg" alt="">
          <div class="container">

            <div class="banner-caption">
              <h1>Giảm giá khách hàng thân thiết</h1>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Slider end -->
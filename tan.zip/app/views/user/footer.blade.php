﻿<footer id="cp_footer">

    <section class="cp_footer-section1">
        <div class="container">
            <h2>Book Your Next Appointment Today!</h2>
            <a href="#" class="cp-btn-style1 buy-now">Đặt hẹn</a>
        </div>
    </section>


    <section class="cp_footer-section2 pd-tb80">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="ft-box-holder">
                        <h3>Giới thiệu</h3>
                        <div class="about-box">
                            <ul class="news">
                                <li><a href="" title="">Về chúng tôi</a></li>
                                <li><a href="" title="">Điều khoản sử dụng</a></li>
                                <li><a href="" title="">Chính sách bảo mật thông tin</a></li>
                                <li><a href="" title="">Quy định thanh toán & giao nhận</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="ft-box-holder">
                        <h3>Liên hệ</h3>
                        <ul class="ft-contact-us-list">
                            <li>CÔNG TY TNHH THƯƠNG MẠI MỸ PHẨM NHỰT TÂN</li>
                            <li><span>Địa chỉ:</span> 29B Đường 37,khu phố 8,Phường Linh Đông
Quận Thủ Đức, TPHCM</li>
                            <li><span>MST:</span>013476213</li>
                           <li><span>Hotline:</span> 0909.656.037</li>
                            <li><span>Email:</span> diachilamtoc@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="ft-box-holder">
                        <h3>Gallery</h3>
                        <ul class="cp_flicker-list">
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-01.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-02.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-03.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-04.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-05.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-06.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-07.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-08.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-09.jpg'}}" alt=""></a></li>
                            <li><a href="#"><img src="{{$_images . 'flickr/flickr-img-10.jpg'}}" alt=""></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="cp_footer-section3">
        <div class="container">
            <div class="text-center"><strong>© 2016 by diachilamtoc.com.vn</strong></div>
            <div class="cp_back-top-holder">
                <span id="cp_back-top">
                    <a href="#"><i class="fa fa-angle-up"></i></a>
                </span>
            </div>
        </div>
    </section>

</footer>
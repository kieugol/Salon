<?php
class ArticlesController extends \BaseController {
	protected $layout = 'user.main';
	public $data = array();
	// load Articles Categories
	public function loadNewsCategories ($alias)
	{
		//load model 
		$Articles = new Articles();
		$ArticlesCat = new ArticlesCat();
		$data['details_cat'] = $ArticlesCat->getTitleArticlesCat($alias);
		$data['list_articles'] = $Articles->getArticlesCategories($alias);
		$this->layout->content = View::make('user.body.news_dir.news_hot_categories',$data);
	}
	// load News Home
	public function loadNewsHome (){
		$Articles = new Articles();
		$ArticlesCat = new ArticlesCat();
		$data['listArticles'] = $Articles->getAllArticles();
		$this->layout->content = View::make('user.body.news_dir.news',$data);
	}
	// load details Articles 
	public function loadArticlesDetails($alias2,$alias3){
		$Articles = new Articles();
		$ArticlesCat = new ArticlesCat();
		$adv = new Adv();
		$data['list_adv']= $adv->getAlladv();
		$data['articles_details'] = $articles_tmp = $Articles->getArticlesDetails($alias3);
		$data['listLinkArticles'] = $Articles->getLinkArticles($alias3,$articles_tmp['categories_id']);
		$data['id_categories_min'] = $ArticlesCat->getMinId();
		$this->layout->content = View::make('user.body.news_dir.articles',$data);
	}
	public function loadArticlesCategories($alias1,$alias2){
		$Articles = new Articles();
		$data['listArticles'] = $Articles->getArticlesCategories($alias2);
		$data['alias_menu'] = $alias1;
		$data['listLinkArticles'] = $Articles->getLinkArticlesCategories($alias1,$alias2);
		$this->layout->content = View::make('user.body.news_dir.articles_categories',$data);
	}
	// load articles details
	
}